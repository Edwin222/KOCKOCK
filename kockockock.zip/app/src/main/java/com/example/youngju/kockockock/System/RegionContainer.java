package com.example.youngju.kockockock.System;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by sleep on 2017-08-15.
 */

public class RegionContainer extends ArrayList<Region> implements Serializable {

    public void SPSort(){

    }

    /*
    public int getWeight(int x, int y){
        APIGetter apiGetter = new APIGetter(APIGetter.SKPAPI_DISTANCE);

        if(x == y) {
            return -z1;
        }


    }*/
}
